﻿namespace FinanciaRed.Model.DTO {
    internal class DTO_WorkType {
        public int IdWorkType {
            get; set;
        }
        public string Type {
            get; set;
        }
    }
}
