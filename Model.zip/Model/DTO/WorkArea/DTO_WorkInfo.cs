﻿namespace FinanciaRed.Model.DTO {
    public class DTO_WorkInfo {
        public int IdWorkType {
            get; set;
        }
        public string WorkType {
            get; set;
        }
        public string WorkArea {
            get; set;
        }
        public float MonthlySalary {
            get; set;
        }
    }
}
