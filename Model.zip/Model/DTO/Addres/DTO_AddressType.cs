﻿namespace FinanciaRed.Model.DTO {
    internal class DTO_AddressType {
        public int IdAddressType {
            get; set;
        }
        public string Type {
            get; set;
        }
    }
}