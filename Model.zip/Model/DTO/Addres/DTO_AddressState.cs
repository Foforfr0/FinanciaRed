﻿namespace FinanciaRed.Model.DTO {
    internal class DTO_AddressState {
        public int IdAddressState {
            get; set;
        }
        public string Name {
            get; set;
        }
    }
}
