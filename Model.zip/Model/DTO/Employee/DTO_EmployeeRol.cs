﻿namespace FinanciaRed.Model.DTO {
    internal class DTO_EmployeeRol {
        public int IdRol {
            get; set;
        }
        public string Rol {
            get; set;
        }
    }
}
