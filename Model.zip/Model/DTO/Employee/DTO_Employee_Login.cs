﻿namespace FinanciaRed.Model.DTO {
    public class DTO_Employee_Login {
        public int IdEmployee {
            get; set;
        }
        public string FirstName {
            get; set;
        }
        public string MiddleName {
            get; set;
        }
        public string LastName {
            get; set;
        }
        public byte[] ProfilePhoto {
            get; set;
        }
        public int IdRol {
            get; set;
        }
        public string Rol {
            get; set;
        }
    }
}
