﻿namespace FinanciaRed.Model.DTO {
    internal class DTO_Employee_ModifyData {
        public int IdEmployee {
            get; set;
        }
        public byte[] ProfilePhoto {
            get; set;
        }
        public string Email {
            get; set;
        }
        public string Password {
            get; set;
        }
    }
}
