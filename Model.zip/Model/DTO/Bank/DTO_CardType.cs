﻿namespace FinanciaRed.Model.DTO {
    internal class DTO_CardType {
        public int IdCardType {
            get; set;
        }
        public string Type {
            get; set;
        }
    }
}
