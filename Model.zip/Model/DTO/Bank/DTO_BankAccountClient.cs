﻿namespace FinanciaRed.Model.DTO {
    public class DTO_BankAccountClient {
        public int IdBankName{
            get; set;
        }
        public string BankName {
            get; set;
        }
        public string CLABE {
            get; set;
        }
        public string CardNumber {
            get; set;
        }
        public int IdCardType {
            get; set;
        }
        public string CardType {
            get; set;
        }
    }
}
