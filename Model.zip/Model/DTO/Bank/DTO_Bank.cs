﻿namespace FinanciaRed.Model.DTO {
    internal class DTO_Bank {
        public int IdBank {
            get; set;
        }
        public string Name {
            get; set;
        }
    }
}