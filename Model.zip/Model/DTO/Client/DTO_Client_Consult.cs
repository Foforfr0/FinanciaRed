﻿namespace FinanciaRed.Model.DTO {
    internal class DTO_Client_Consult {
        public int IdClient {
            get; set;
        }
        public string FirstName {
            get; set;
        }
        public string MiddleName {
            get; set;
        }
        public string LastName {
            get; set;
        }
        public string CodeRFC {
            get; set;
        }
        public string CodeCURP {
            get; set;
        }
        public int IdStatusClient {
            get; set;
        }
        public string StatusClient {
            get; set;
        }
    }
}