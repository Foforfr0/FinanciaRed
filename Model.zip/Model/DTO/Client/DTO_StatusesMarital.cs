﻿namespace FinanciaRed.Model.DTO {
    internal class DTO_StatusesMarital {
        public int IdStatusMarital {
            get; set;
        }
        public string Status {
            get; set;
        }
    }
}
