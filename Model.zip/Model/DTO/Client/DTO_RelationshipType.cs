﻿namespace FinanciaRed.Model.DTO {
    internal class DTO_RelationshipType {
        public int IdRelationshipType {
            get; set;
        }
        public string Type {
            get; set;
        }
    }
}
