﻿namespace FinanciaRed.Model.DTO {
    internal class DTO_CreditApplication_Details {
        public int IdCreditApplication {
            get; set;
        }
    }
}
