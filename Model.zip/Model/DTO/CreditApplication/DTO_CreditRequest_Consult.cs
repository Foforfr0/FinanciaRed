﻿namespace FinanciaRed.Model.DTO {
    internal class DTO_CreditRequest_Consult {
        public int IdCreditRequest {
            get; set;
        }
        public string ClientName {
            get; set;
        }
        public string RequestedDate {
            get; set;
        }
        public string State {
            get; set;
        }
    }
}
