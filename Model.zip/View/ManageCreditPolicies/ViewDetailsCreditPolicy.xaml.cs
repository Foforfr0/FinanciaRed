﻿using FinanciaRed.Model.DTO;
using System.Windows;

namespace FinanciaRed.View.ManageCreditPolicies {
    /// <summary>
    /// Interaction logic for ViewDetailsCreditPolicy.xaml
    /// </summary>
    public partial class ViewDetailsCreditPolicy : Window {
        private DTO_CreditPolicy_Consult selectedCreditPolicy = null;

        public ViewDetailsCreditPolicy (DTO_CreditPolicy_Consult selectedCreditPolicy) {
            InitializeComponent ();

            this.selectedCreditPolicy = selectedCreditPolicy;

            ShowDataCreditPolicy ();
        }

        private void ShowDataCreditPolicy () {
            textBox_Name.Text = selectedCreditPolicy.Name;
            textBox_Description.Text = selectedCreditPolicy.Description;
            datePicker_DateStart.SelectedDate = selectedCreditPolicy.DateStart;
            datePicker_DateEnd.SelectedDate = selectedCreditPolicy.DateEnd;
        }

        private void ClickModifyCreditPolicy (object sender, RoutedEventArgs e) {
            textBox_Name.IsReadOnly = false;
            textBox_Description.IsReadOnly = false;
            datePicker_DateStart.IsEnabled = true;
            datePicker_DateEnd.IsEnabled = true;
            button_Modify.Visibility = Visibility.Collapsed;
            grid_ButtonsActions.Visibility = Visibility.Visible;
        }

        private void ClickCancel (object sender, RoutedEventArgs e) {
            MessageBoxResult result = MessageBox.Show (
                "¿Está seguro de cancelar?\nNo se podrán recuperar los datos.",
                "Cancelar modificación.",
                MessageBoxButton.YesNo
            );
            if (result == MessageBoxResult.Yes) {
                ShowDataCreditPolicy ();

                textBox_Name.IsReadOnly = true;
                textBox_Description.IsReadOnly = true;
                datePicker_DateStart.IsEnabled = false;
                datePicker_DateEnd.IsEnabled = false;
                button_Modify.Visibility = Visibility.Visible;
                grid_ButtonsActions.Visibility = Visibility.Collapsed;
            }
        }

        private void ClickFinishModification (object sender, RoutedEventArgs e) {

        }
    }
}
