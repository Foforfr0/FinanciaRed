﻿using System.Windows;

namespace FinanciaRed.View.ManageCredits {
    /// <summary>
    /// Interaction logic for ViewDetailsCredit.xaml
    /// </summary>
    public partial class ViewDetailsCredit : Window {
        public ViewDetailsCredit (int idCredit) {
            InitializeComponent ();
        }
    }
}
