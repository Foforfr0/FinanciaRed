﻿using System.Windows;

namespace FinanciaRed.View.ManageCreditApplications {
    /// <summary>
    /// Interaction logic for ViewDetailsCreditApplication.xaml
    /// </summary>
    public partial class ViewDetailsCreditApplication : Window {
        public ViewDetailsCreditApplication (int idCreditApplication) {
            InitializeComponent ();
        }
    }
}
