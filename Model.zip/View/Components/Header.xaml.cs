﻿using System.Windows.Controls;

namespace FinanciaRed.View.Components {
    /// <summary>
    /// Interaction logic for Header.xaml
    /// </summary>
    public partial class Header : UserControl {
        public Header () {
            InitializeComponent ();
        }
    }
}
