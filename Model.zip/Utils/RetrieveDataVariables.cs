﻿namespace FinanciaRed.Utils {
    internal class RetrieveDataVariables {
        
    }
}
